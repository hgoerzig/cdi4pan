*Content description:*

This zipfile contains 10 files (including this one):

*1. README_FIRST*

*2. README_ownership_and_usage_notice*
General information and usage

*3. PID..._metaData.txt*
Contains all metadata from this dataset - HUMAN READABLE
+ content of the original datafile - including the values.

*4. PID..._metadata.hdf5*
Contains all metadata. Format: hdf5 - MACHINE READABLE

*5. PID..._metadata.json*
Contains all metadata. Format: json - MACHINE READABLE

*6. PID..._metadata.yaml*
Contains all metadata. Format: yaml - MACHINE READABLE

*7. plot1.jpg*
JPEG image of the Raw XAFS

*8. plot2.jpg*
JPEG image of the Normalized XAFS

*9. plot3.jpg*
JPEG image of Chi(k)

*9. plot4.jpg*
JPEG image of Chi(R)

NOTE: The size of all image windows can be changed!