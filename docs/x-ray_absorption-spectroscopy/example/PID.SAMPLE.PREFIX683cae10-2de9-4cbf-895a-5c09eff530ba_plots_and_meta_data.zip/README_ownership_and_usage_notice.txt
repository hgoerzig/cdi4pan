Thank you for using RefXAS.
Please be aware, do not misuse the data, cite properly when you use this data
and please always cite RefXAS!
For any questions, please write to paripsa@uni-wuppertal.de

Thank you for supporting the RefXAS community.